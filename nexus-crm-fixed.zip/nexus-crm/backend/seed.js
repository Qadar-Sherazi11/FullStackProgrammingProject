const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const dotenv = require('dotenv');

dotenv.config();

const User = require('./models/User');
const Customer = require('./models/Customer');

const customers = [
  { name: 'Acme Corporation', email: 'billing@acme.com', phone: '+1-555-0101', company: 'Acme Corp', status: 'Active', address: '123 Main St, New York, NY', notes: 'Long-term enterprise client' },
  { name: 'Nexus Labs', email: 'contact@nexuslabs.io', phone: '+1-555-0102', company: 'Nexus Labs', status: 'Lead', address: '456 Tech Blvd, San Francisco, CA', notes: 'R&D focused company' },
  { name: 'Stellar Financial', email: 'ops@stellarfin.com', phone: '+1-555-0103', company: 'Stellar Financial', status: 'Active', address: '789 Wall St, New York, NY', notes: 'Wealth management firm' },
  { name: 'Horizon Media', email: 'hello@horizon.media', phone: '+1-555-0104', company: 'Horizon Media', status: 'Inactive', address: '321 Sunset Blvd, Los Angeles, CA', notes: 'Digital marketing agency' },
  { name: 'AquaDynamics Inc', email: 'info@aquadynamics.com', phone: '+1-555-0105', company: 'AquaDynamics', status: 'Active', address: '654 Ocean Dr, Miami, FL', notes: 'Marine tech company' },
  { name: 'Silverline Consulting', email: 'bd@silverline.co', phone: '+1-555-0106', company: 'Silverline', status: 'Lead', address: '987 Park Ave, Chicago, IL', notes: 'Management consultants' },
  { name: 'TechBridge Solutions', email: 'sales@techbridge.com', phone: '+1-555-0107', company: 'TechBridge', status: 'Active', address: '111 Innovation Way, Austin, TX', notes: 'IT solutions provider' },
  { name: 'Green Earth Co', email: 'contact@greenearth.org', phone: '+1-555-0108', company: 'Green Earth', status: 'Lead', address: '222 Eco Rd, Portland, OR', notes: 'Sustainability startup' },
  { name: 'Peak Performance', email: 'info@peakperfx.com', phone: '+1-555-0109', company: 'Peak Performance', status: 'Active', address: '333 Summit Ave, Denver, CO', notes: 'Sports analytics firm' },
  { name: 'Solaris Energy', email: 'contracts@solaris.energy', phone: '+1-555-0110', company: 'Solaris Energy', status: 'Active', address: '444 Solar Way, Phoenix, AZ', notes: 'Renewable energy provider' },
  { name: 'BluePrint Architects', email: 'design@blueprint.arch', phone: '+1-555-0111', company: 'BluePrint', status: 'Inactive', address: '555 Design St, Seattle, WA', notes: 'Architecture firm' },
  { name: 'DataSphere Analytics', email: 'hello@datasphere.io', phone: '+1-555-0112', company: 'DataSphere', status: 'Lead', address: '666 Data Dr, Boston, MA', notes: 'Big data analytics' },
  { name: 'Meridian Health', email: 'admin@meridianhealth.com', phone: '+1-555-0113', company: 'Meridian Health', status: 'Active', address: '777 Medical Blvd, Houston, TX', notes: 'Healthcare services' },
  { name: 'CloudPeak Systems', email: 'info@cloudpeak.sys', phone: '+1-555-0114', company: 'CloudPeak', status: 'Active', address: '888 Cloud Ave, San Jose, CA', notes: 'Cloud infrastructure' },
  { name: 'Falcon Logistics', email: 'ops@falconlogistics.net', phone: '+1-555-0115', company: 'Falcon Logistics', status: 'Lead', address: '999 Cargo Rd, Dallas, TX', notes: 'Supply chain management' },
  { name: 'Nova Creative Studio', email: 'hello@novastudio.design', phone: '+1-555-0116', company: 'Nova Studio', status: 'Inactive', address: '101 Creative Lane, Nashville, TN', notes: 'Branding and design agency' },
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/nexus-crm');
    console.log('Connected to MongoDB');

    // Create admin user
    await User.deleteMany({});
    const adminUser = await User.create({
      name: 'Admin User',
      email: 'admin@nexuscrm.com',
      password: 'admin123',
      role: 'admin',
    });
    console.log('Admin user created: admin@nexuscrm.com / admin123');

    // Seed customers
    await Customer.deleteMany({});
    const customersWithUser = customers.map(c => ({ ...c, createdBy: adminUser._id }));
    await Customer.insertMany(customersWithUser);
    console.log(`${customers.length} customers seeded`);

    console.log('\n✅ Database seeded successfully!');
    console.log('Login: admin@nexuscrm.com | Password: admin123');
    process.exit(0);
  } catch (error) {
    console.error('Seed error:', error);
    process.exit(1);
  }
}

seed();
