const mongoose = require('mongoose');

const serviceRowSchema = new mongoose.Schema({
  description: { type: String, required: true },
  hours: { type: Number, required: true, min: 0 },
  rate: { type: Number, required: true, min: 0 },
  total: { type: Number },
});

const invoiceSchema = new mongoose.Schema({
  invoiceNumber: {
    type: String,
    unique: true,
  },
  customer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    required: true,
  },
  services: [serviceRowSchema],
  subtotal: { type: Number, default: 0 },
  tax: { type: Number, default: 0 },
  total: { type: Number, default: 0 },
  status: {
    type: String,
    enum: ['Draft', 'Sent', 'Paid'],
    default: 'Draft',
  },
  dueDate: { type: Date },
  notes: { type: String },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
}, { timestamps: true });

// Auto-generate invoice number
invoiceSchema.pre('save', async function (next) {
  if (!this.invoiceNumber) {
    const count = await mongoose.model('Invoice').countDocuments();
    this.invoiceNumber = `INV-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
  }

  // Calculate totals
  this.subtotal = this.services.reduce((sum, s) => {
    s.total = s.hours * s.rate;
    return sum + s.total;
  }, 0);
  this.tax = parseFloat((this.subtotal * 0.1).toFixed(2));
  this.total = parseFloat((this.subtotal + this.tax).toFixed(2));
  next();
});

module.exports = mongoose.model('Invoice', invoiceSchema);
