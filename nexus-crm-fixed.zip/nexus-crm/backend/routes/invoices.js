const express = require('express');
const router = express.Router();
const Invoice = require('../models/Invoice');
const Customer = require('../models/Customer');
const { protect } = require('../middleware/auth');
const PDFDocument = require('pdfkit');

router.use(protect);

// @route GET /api/invoices
router.get('/', async (req, res) => {
  try {
    const invoices = await Invoice.find()
      .populate('customer', 'name email company')
      .sort({ createdAt: -1 });
    res.json(invoices);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route GET /api/invoices/:id
router.get('/:id', async (req, res) => {
  try {
    const invoice = await Invoice.findById(req.params.id)
      .populate('customer', 'name email company address phone');
    if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
    res.json(invoice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route POST /api/invoices
router.post('/', async (req, res) => {
  try {
    const { customer, services, dueDate, notes } = req.body;

    if (!customer || !services || services.length === 0) {
      return res.status(400).json({ message: 'Customer and at least one service are required' });
    }

    const invoice = await Invoice.create({
      customer, services, dueDate, notes,
      createdBy: req.user._id,
    });

    const populated = await Invoice.findById(invoice._id).populate('customer', 'name email company');
    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route DELETE /api/invoices/:id
router.delete('/:id', async (req, res) => {
  try {
    const invoice = await Invoice.findByIdAndDelete(req.params.id);
    if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
    res.json({ message: 'Invoice deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// @route GET /api/invoices/:id/pdf
router.get('/:id/pdf', async (req, res) => {
  try {
    const invoice = await Invoice.findById(req.params.id)
      .populate('customer', 'name email company address phone');

    if (!invoice) return res.status(404).json({ message: 'Invoice not found' });

    const doc = new PDFDocument({ margin: 50 });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=${invoice.invoiceNumber}.pdf`);

    doc.pipe(res);

    // Header
    doc.fontSize(24).font('Helvetica-Bold').text('NEXUS CRM', 50, 50);
    doc.fontSize(10).font('Helvetica').fillColor('#666').text('Enterprise Invoice', 50, 78);

    doc.fillColor('#000');
    doc.fontSize(20).font('Helvetica-Bold').text('INVOICE', 400, 50, { align: 'right' });
    doc.fontSize(10).font('Helvetica').text(invoice.invoiceNumber, 400, 78, { align: 'right' });
    doc.text(`Date: ${new Date(invoice.createdAt).toLocaleDateString()}`, 400, 92, { align: 'right' });

    if (invoice.dueDate) {
      doc.text(`Due: ${new Date(invoice.dueDate).toLocaleDateString()}`, 400, 106, { align: 'right' });
    }

    doc.moveTo(50, 130).lineTo(545, 130).stroke();

    // Bill To
    doc.fontSize(10).font('Helvetica-Bold').text('BILL TO:', 50, 145);
    doc.font('Helvetica').text(invoice.customer.name, 50, 160);
    doc.text(invoice.customer.email, 50, 175);
    if (invoice.customer.company) doc.text(invoice.customer.company, 50, 190);

    // From
    doc.font('Helvetica-Bold').text('FROM:', 350, 145);
    doc.font('Helvetica').text('Nexus CRM Corp', 350, 160);
    doc.text('128 Enterprise Way', 350, 175);
    doc.text('Silicon Valley, CA 94043', 350, 190);

    // Table Header
    const tableTop = 240;
    doc.fillColor('#1a237e').rect(50, tableTop, 495, 20).fill();
    doc.fillColor('#fff').fontSize(10).font('Helvetica-Bold');
    doc.text('DESCRIPTION', 60, tableTop + 5);
    doc.text('HOURS', 340, tableTop + 5);
    doc.text('RATE', 400, tableTop + 5);
    doc.text('TOTAL', 480, tableTop + 5);

    // Table rows
    let y = tableTop + 30;
    doc.fillColor('#000').font('Helvetica');
    invoice.services.forEach((service, i) => {
      if (i % 2 === 0) {
        doc.fillColor('#f5f5f5').rect(50, y - 5, 495, 20).fill();
      }
      doc.fillColor('#000');
      doc.text(service.description, 60, y, { width: 270 });
      doc.text(service.hours.toString(), 340, y);
      doc.text(`$${service.rate.toFixed(2)}`, 400, y);
      doc.text(`$${(service.hours * service.rate).toFixed(2)}`, 480, y);
      y += 25;
    });

    // Totals
    y += 20;
    doc.moveTo(350, y).lineTo(545, y).stroke();
    y += 10;
    doc.font('Helvetica').text('Subtotal:', 350, y);
    doc.text(`$${invoice.subtotal.toFixed(2)}`, 480, y);
    y += 18;
    doc.text('Tax (10%):', 350, y);
    doc.text(`$${invoice.tax.toFixed(2)}`, 480, y);
    y += 18;
    doc.font('Helvetica-Bold').fontSize(12);
    doc.text('TOTAL:', 350, y);
    doc.text(`$${invoice.total.toFixed(2)}`, 480, y);

    if (invoice.notes) {
      y += 40;
      doc.fontSize(10).font('Helvetica-Bold').text('Notes:', 50, y);
      doc.font('Helvetica').text(invoice.notes, 50, y + 15);
    }

    doc.fontSize(9).fillColor('#666').text('Thank you for your business!', 50, 720, { align: 'center' });

    doc.end();
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
