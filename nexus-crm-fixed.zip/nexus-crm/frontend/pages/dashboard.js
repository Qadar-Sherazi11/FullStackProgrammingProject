import { useEffect, useState } from 'react';
import Layout from '../components/layout/Layout';
import withAuth from '../components/ui/withAuth';
import api from '../lib/api';
import { useAuth } from '../context/AuthContext';
import Link from 'next/link';

function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const { data } = await api.get('/dashboard/stats');
      setStats(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const statusBadge = (status) => {
    const map = { Active: 'badge-active', Lead: 'badge-lead', Inactive: 'badge-inactive' };
    return <span className={`badge ${map[status] || ''}`}>{status}</span>;
  };

  return (
    <Layout>
      <div className="page-header">
        <div className="page-title">
          <h1>Executive Overview</h1>
          <p>Welcome back, {user?.name} — here's your CRM at a glance.</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <Link href="/customers/add">
            <button className="btn-primary">+ New Customer</button>
          </Link>
          <Link href="/invoices/create">
            <button className="btn-secondary">+ New Invoice</button>
          </Link>
        </div>
      </div>

      {loading ? (
        <div className="loading">Loading dashboard...</div>
      ) : (
        <>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="label">Total Customers</div>
              <div className="value">{stats?.totalCustomers ?? 0}</div>
            </div>
            <div className="stat-card">
              <div className="label">Active Customers</div>
              <div className="value" style={{ color: '#2e7d32' }}>{stats?.activeCustomers ?? 0}</div>
            </div>
            <div className="stat-card">
              <div className="label">Active Leads</div>
              <div className="value" style={{ color: '#1565c0' }}>{stats?.leads ?? 0}</div>
            </div>
            <div className="stat-card">
              <div className="label">Total Revenue</div>
              <div className="value" style={{ color: '#1a237e', fontSize: 22 }}>${Number(stats?.revenue ?? 0).toLocaleString()}</div>
            </div>
          </div>

          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Recent Customers</h3>
              <Link href="/customers">
                <span style={{ color: 'var(--accent)', fontSize: 13, cursor: 'pointer' }}>View All →</span>
              </Link>
            </div>

            {stats?.recentCustomers?.length === 0 ? (
              <p style={{ color: '#666', textAlign: 'center', padding: 20 }}>No customers yet. <Link href="/customers/add" style={{ color: 'var(--accent)' }}>Add one!</Link></p>
            ) : (
              <div className="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Company</th>
                      <th>Status</th>
                      <th>Created</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stats?.recentCustomers?.map((c) => (
                      <tr key={c._id}>
                        <td style={{ fontWeight: 600 }}>{c.name}</td>
                        <td>{c.email}</td>
                        <td>{c.company || '—'}</td>
                        <td>{statusBadge(c.status)}</td>
                        <td>{new Date(c.createdAt).toLocaleDateString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 16 }}>
            <div className="card" style={{ background: 'linear-gradient(135deg, var(--primary), var(--primary-light))', color: 'white' }}>
              <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: 1, opacity: 0.8 }}>Quick Actions</div>
              <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 10 }}>
                <Link href="/customers/add">
                  <button style={{ background: 'rgba(255,255,255,0.15)', color: 'white', width: '100%', textAlign: 'left', padding: '10px 14px' }}>
                    👤 Add New Customer
                  </button>
                </Link>
                <Link href="/invoices/create">
                  <button style={{ background: 'rgba(255,255,255,0.15)', color: 'white', width: '100%', textAlign: 'left', padding: '10px 14px' }}>
                    🧾 Generate Invoice
                  </button>
                </Link>
                <Link href="/customers">
                  <button style={{ background: 'rgba(255,255,255,0.15)', color: 'white', width: '100%', textAlign: 'left', padding: '10px 14px' }}>
                    📋 View All Customers
                  </button>
                </Link>
              </div>
            </div>

            <div className="card">
              <div style={{ fontSize: 12, textTransform: 'uppercase', letterSpacing: 1, color: '#666', marginBottom: 16 }}>System Info</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid #f0f0f0' }}>
                  <span style={{ color: '#666' }}>System Status</span>
                  <span style={{ color: '#2e7d32', fontWeight: 600 }}>● Operational</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid #f0f0f0' }}>
                  <span style={{ color: '#666' }}>Logged in as</span>
                  <span style={{ fontWeight: 600 }}>{user?.name}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0' }}>
                  <span style={{ color: '#666' }}>Role</span>
                  <span style={{ fontWeight: 600, textTransform: 'capitalize' }}>{user?.role}</span>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </Layout>
  );
}

export default withAuth(Dashboard);
