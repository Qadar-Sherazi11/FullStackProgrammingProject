import { useState } from 'react';
import Layout from '../components/layout/Layout';
import withAuth from '../components/ui/withAuth';
import { useAuth } from '../context/AuthContext';
import api from '../lib/api';
import toast from 'react-hot-toast';

function Settings() {
  const { user } = useAuth();
  const [profileForm, setProfileForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    bio: '',
  });
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [darkMode, setDarkMode] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPw, setSavingPw] = useState(false);

  const handleProfileChange = (e) => setProfileForm({ ...profileForm, [e.target.name]: e.target.value });
  const handlePwChange = (e) => setPwForm({ ...pwForm, [e.target.name]: e.target.value });

  const handleProfileSave = async (e) => {
    e.preventDefault();
    if (!profileForm.name.trim()) return toast.error('Name cannot be empty');
    setSavingProfile(true);
    // Simulate save — in a real app this would call PATCH /api/auth/profile
    setTimeout(() => {
      toast.success('Profile saved successfully!');
      setSavingProfile(false);
    }, 800);
  };

  const handlePasswordChange = (e) => {
    e.preventDefault();
    if (!pwForm.currentPassword || !pwForm.newPassword) return toast.error('Please fill all password fields');
    if (pwForm.newPassword.length < 6) return toast.error('New password must be at least 6 characters');
    if (pwForm.newPassword !== pwForm.confirmPassword) return toast.error('Passwords do not match');
    setSavingPw(true);
    setTimeout(() => {
      toast.success('Password updated successfully!');
      setPwForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setSavingPw(false);
    }, 800);
  };

  return (
    <Layout>
      <div className="page-header">
        <div className="page-title">
          <h1>Account Settings</h1>
          <p>Manage your enterprise profile and security protocols.</p>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20, alignItems: 'start' }}>
        {/* Left column */}
        <div>
          {/* Personal Profile */}
          <div className="card" style={{ marginBottom: 20 }}>
            <h3 style={{ fontWeight: 700, marginBottom: 4 }}>👤 Personal Profile</h3>
            <p style={{ color: '#666', fontSize: 13, marginBottom: 20 }}>Update your name and personal details.</p>

            <form onSubmit={handleProfileSave}>
              <div className="form-row">
                <div className="form-group">
                  <label>First Name</label>
                  <input name="name" value={profileForm.name} onChange={handleProfileChange} placeholder="First name" />
                </div>
                <div className="form-group">
                  <label>Email Address</label>
                  <input name="email" type="email" value={profileForm.email} onChange={handleProfileChange} />
                </div>
              </div>
              <div className="form-group">
                <label>Bio</label>
                <textarea
                  name="bio"
                  value={profileForm.bio}
                  onChange={handleProfileChange}
                  rows={3}
                  placeholder="A short bio about yourself..."
                />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button type="submit" className="btn-primary" disabled={savingProfile}>
                  {savingProfile ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>

          {/* Password */}
          <div className="card" style={{ marginBottom: 20 }}>
            <h3 style={{ fontWeight: 700, marginBottom: 4 }}>🔒 Change Password</h3>
            <p style={{ color: '#666', fontSize: 13, marginBottom: 20 }}>Update your account password.</p>

            <form onSubmit={handlePasswordChange}>
              <div className="form-group">
                <label>Current Password</label>
                <input type="password" name="currentPassword" value={pwForm.currentPassword} onChange={handlePwChange} placeholder="Enter current password" />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>New Password</label>
                  <input type="password" name="newPassword" value={pwForm.newPassword} onChange={handlePwChange} placeholder="Min. 6 characters" />
                </div>
                <div className="form-group">
                  <label>Confirm New Password</label>
                  <input type="password" name="confirmPassword" value={pwForm.confirmPassword} onChange={handlePwChange} placeholder="Re-enter new password" />
                </div>
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button type="submit" className="btn-primary" disabled={savingPw}>
                  {savingPw ? 'Updating...' : 'Update Password'}
                </button>
              </div>
            </form>
          </div>

          {/* Appearance */}
          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: 16 }}>🎨 Appearance</h3>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
              <div>
                <div style={{ fontWeight: 600 }}>Dark Mode</div>
                <div style={{ fontSize: 12, color: '#666' }}>Reduce eye strain at night</div>
              </div>
              <div
                onClick={() => { setDarkMode(!darkMode); toast('Dark mode coming soon!', { icon: '🌙' }); }}
                style={{
                  width: 44, height: 24, background: darkMode ? 'var(--primary)' : '#ccc',
                  borderRadius: 12, cursor: 'pointer', position: 'relative', transition: 'background 0.2s',
                }}
              >
                <div style={{
                  width: 20, height: 20, background: 'white', borderRadius: '50%',
                  position: 'absolute', top: 2, left: darkMode ? 22 : 2, transition: 'left 0.2s',
                }} />
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0' }}>
              <div>
                <div style={{ fontWeight: 600 }}>Sidebar Layout</div>
                <div style={{ fontSize: 12, color: '#666' }}>Choose your preferred sidebar style</div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn-primary btn-sm">Standard</button>
                <button className="btn-secondary btn-sm" onClick={() => toast('Compact mode coming soon!', { icon: '📐' })}>Compact</button>
              </div>
            </div>
          </div>
        </div>

        {/* Right column */}
        <div>
          <div className="card" style={{ background: 'linear-gradient(135deg, var(--primary), var(--primary-light))', color: 'white', marginBottom: 16 }}>
            <div style={{ fontSize: 12, opacity: 0.7, marginBottom: 8 }}>🛡️ SECURITY LEVEL: HIGH</div>
            <h3 style={{ fontWeight: 700, marginBottom: 8 }}>Privacy & Security</h3>
            <p style={{ fontSize: 13, opacity: 0.85, lineHeight: 1.6 }}>
              Your account is protected with JWT authentication and encrypted password storage.
            </p>
          </div>

          <div className="card">
            <h3 style={{ fontWeight: 700, marginBottom: 16 }}>🔔 Notification Preferences</h3>
            {[
              { label: 'New Lead Assigned', enabled: true },
              { label: 'Customer Updated', enabled: true },
              { label: 'Invoice Generated', enabled: true },
              { label: 'System Alerts', enabled: false },
            ].map((item) => (
              <div key={item.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <span style={{ fontSize: 13 }}>{item.label}</span>
                <span style={{ color: item.enabled ? '#2e7d32' : '#999', fontWeight: 600, fontSize: 12 }}>
                  {item.enabled ? '✓ ON' : 'OFF'}
                </span>
              </div>
            ))}
          </div>

          <div className="card" style={{ marginTop: 16 }}>
            <h3 style={{ fontWeight: 700, marginBottom: 12 }}>ℹ️ Account Info</h3>
            <div style={{ fontSize: 13, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: '#666' }}>User ID</span>
                <span style={{ fontFamily: 'monospace', fontSize: 11 }}>{user?.id?.slice(-8)}...</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: '#666' }}>Role</span>
                <span style={{ fontWeight: 600, textTransform: 'capitalize' }}>{user?.role}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: '#666' }}>Plan</span>
                <span style={{ fontWeight: 600 }}>Enterprise</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default withAuth(Settings);
