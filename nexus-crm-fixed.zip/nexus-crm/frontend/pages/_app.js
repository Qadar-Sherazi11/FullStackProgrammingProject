import '../styles/globals.css';
import { AuthProvider } from '../context/AuthContext';
import { Toaster } from 'react-hot-toast';

export default function App({ Component, pageProps }) {
  return (
    <AuthProvider>
      <Component {...pageProps} />
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: { fontSize: '14px' },
          success: { iconTheme: { primary: '#4caf50', secondary: '#fff' } },
          error: { iconTheme: { primary: '#f44336', secondary: '#fff' } },
        }}
      />
    </AuthProvider>
  );
}
