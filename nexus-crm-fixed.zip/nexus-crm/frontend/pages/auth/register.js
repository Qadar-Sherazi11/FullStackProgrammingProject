import { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

export default function Register() {
  const { register } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [agreed, setAgreed] = useState(false);

  const handleChange = (e) => {
    // Clear error as soon as user starts correcting their input
    if (error) setError('');
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Client-side validation
    if (!form.name.trim() || !form.email.trim() || !form.password || !form.confirmPassword) {
      setError('Please fill in all fields');
      return;
    }
    if (form.name.trim().length < 2) {
      setError('Name must be at least 2 characters');
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      setError('Please enter a valid email address');
      return;
    }
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    if (form.password !== form.confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (!agreed) {
      setError('Please agree to the Terms of Service to continue');
      return;
    }

    setLoading(true);
    try {
      // register() in AuthContext handles localStorage + redirect on success
      // It throws on API error, so we only reach the catch if something went wrong
      await register(form.name.trim(), form.email.trim().toLowerCase(), form.password);
      // NOTE: No toast here — page will redirect to dashboard immediately.
      // Showing a toast on an about-to-unmount component causes React warnings.
    } catch (err) {
      // Server returned an error (duplicate email, validation, server error, network, etc.)
      const msg =
        err.response?.data?.message ||
        (err.message === 'Network Error' ? 'Cannot connect to server. Is the backend running?' : 'Registration failed. Please try again.');
      setError(msg);
      setLoading(false); // Only reset loading on error; on success the page redirects
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <div className="auth-left">
          <div style={{ fontSize: 32, marginBottom: 12 }}>✦</div>
          <h1>Nexus CRM</h1>
          <p style={{ marginTop: 8, lineHeight: 1.6 }}>Enterprise-grade customer intelligence for high-velocity teams.</p>
          <div style={{ marginTop: 28 }}>
            <div style={{ padding: '14px', background: 'rgba(255,255,255,0.1)', borderRadius: 8, marginBottom: 12 }}>
              <div style={{ fontWeight: 600, fontSize: 13 }}>📈 Advanced Analytics</div>
              <div style={{ fontSize: 12, marginTop: 4, opacity: 0.8 }}>Real-time data visualization to drive your revenue growth.</div>
            </div>
            <div style={{ padding: '14px', background: 'rgba(255,255,255,0.1)', borderRadius: 8 }}>
              <div style={{ fontWeight: 600, fontSize: 13 }}>🔒 Enterprise Security</div>
              <div style={{ fontSize: 12, marginTop: 4, opacity: 0.8 }}>JWT-based auth with encrypted password storage.</div>
            </div>
          </div>
        </div>

        <div className="auth-right">
          <h2>Create your workspace</h2>
          <p className="subtitle">Join thousands of enterprises optimizing their workflows today.</p>

          {error && (
            <div className="error-msg" role="alert">
              ⚠️ {error}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <input
                id="name"
                type="text"
                name="name"
                placeholder="Enter your full name"
                value={form.name}
                onChange={handleChange}
                autoComplete="name"
                disabled={loading}
              />
            </div>

            <div className="form-group">
              <label htmlFor="email">Work Email</label>
              <input
                id="email"
                type="email"
                name="email"
                placeholder="name@company.com"
                value={form.email}
                onChange={handleChange}
                autoComplete="email"
                disabled={loading}
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="password">Password</label>
                <input
                  id="password"
                  type="password"
                  name="password"
                  placeholder="Min. 6 characters"
                  value={form.password}
                  onChange={handleChange}
                  autoComplete="new-password"
                  disabled={loading}
                />
              </div>
              <div className="form-group">
                <label htmlFor="confirmPassword">Confirm Password</label>
                <input
                  id="confirmPassword"
                  type="password"
                  name="confirmPassword"
                  placeholder="Re-enter password"
                  value={form.confirmPassword}
                  onChange={handleChange}
                  autoComplete="new-password"
                  disabled={loading}
                />
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <input
                type="checkbox"
                id="agree"
                checked={agreed}
                onChange={(e) => { setAgreed(e.target.checked); if (error) setError(''); }}
                style={{ width: 'auto', cursor: 'pointer' }}
                disabled={loading}
              />
              <label htmlFor="agree" style={{ fontWeight: 'normal', marginBottom: 0, fontSize: 13, color: '#666', cursor: 'pointer' }}>
                I agree to the{' '}
                <span style={{ color: 'var(--primary)', fontWeight: 600 }}>Terms of Service</span>
                {' '}and{' '}
                <span style={{ color: 'var(--primary)', fontWeight: 600 }}>Privacy Policy</span>
              </label>
            </div>

            <button
              type="submit"
              className="btn-primary"
              style={{ width: '100%', padding: '12px', fontSize: 15, opacity: loading ? 0.75 : 1 }}
              disabled={loading}
            >
              {loading ? '⏳ Creating account...' : 'CREATE ACCOUNT'}
            </button>
          </form>

          <div style={{ textAlign: 'center', marginTop: 24, fontSize: 14, color: '#666' }}>
            Already have an account?{' '}
            <Link href="/auth/login" style={{ color: 'var(--primary)', fontWeight: 600 }}>
              Sign In
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
