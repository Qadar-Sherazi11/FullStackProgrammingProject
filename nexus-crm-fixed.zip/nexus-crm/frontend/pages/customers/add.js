import { useState } from 'react';
import { useRouter } from 'next/router';
import Layout from '../../components/layout/Layout';
import withAuth from '../../components/ui/withAuth';
import CustomerForm from '../../components/ui/CustomerForm';
import api from '../../lib/api';
import toast from 'react-hot-toast';
import Link from 'next/link';

function AddCustomer() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (form) => {
    setLoading(true);
    try {
      await api.post('/customers', form);
      toast.success('Customer added successfully!');
      router.push('/customers');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add customer');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="page-header">
        <div className="page-title">
          <div style={{ fontSize: 13, color: '#666', marginBottom: 4 }}>
            <Link href="/customers">Customers</Link> › Add New
          </div>
          <h1>Add New Customer</h1>
        </div>
      </div>

      <div className="card" style={{ maxWidth: 720 }}>
        <CustomerForm onSubmit={handleSubmit} loading={loading} submitLabel="Add Customer" />
      </div>
    </Layout>
  );
}

export default withAuth(AddCustomer);
