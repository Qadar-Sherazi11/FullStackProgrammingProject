import { useEffect, useState, useCallback } from 'react';
import Layout from '../../components/layout/Layout';
import withAuth from '../../components/ui/withAuth';
import api from '../../lib/api';
import Link from 'next/link';
import { useRouter } from 'next/router';
import toast from 'react-hot-toast';

function Customers() {
  const router = useRouter();
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [deleteId, setDeleteId] = useState(null);

  const fetchCustomers = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: 10 };
      if (search) params.search = search;
      if (statusFilter !== 'All') params.status = statusFilter;
      const { data } = await api.get('/customers', { params });
      setCustomers(data.customers);
      setTotalPages(data.pages);
      setTotal(data.total);
    } catch (err) {
      toast.error('Failed to load customers');
    } finally {
      setLoading(false);
    }
  }, [page, search, statusFilter]);

  useEffect(() => {
    fetchCustomers();
  }, [fetchCustomers]);

  // debounce search
  useEffect(() => {
    setPage(1);
  }, [search, statusFilter]);

  const handleDelete = async () => {
    try {
      await api.delete(`/customers/${deleteId}`);
      toast.success('Customer deleted successfully');
      setDeleteId(null);
      fetchCustomers();
    } catch (err) {
      toast.error('Failed to delete customer');
    }
  };

  const statusBadge = (status) => {
    const map = { Active: 'badge-active', Lead: 'badge-lead', Inactive: 'badge-inactive' };
    return <span className={`badge ${map[status] || ''}`}>{status}</span>;
  };

  return (
    <Layout>
      <div className="page-header">
        <div className="page-title">
          <h1>Customer Directory</h1>
          <p>Manage and track your enterprise client relationships. ({total} total)</p>
        </div>
        <Link href="/customers/add">
          <button className="btn-primary">👤 Add Customer</button>
        </Link>
      </div>

      <div className="card">
        {/* Filter Bar */}
        <div className="filter-bar">
          <div className="search-input">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              placeholder="Search customers by name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="filter-tabs">
            {['All', 'Active', 'Lead', 'Inactive'].map((s) => (
              <button
                key={s}
                className={`filter-tab ${statusFilter === s ? 'active' : ''}`}
                onClick={() => setStatusFilter(s)}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        {loading ? (
          <div className="loading">Loading customers...</div>
        ) : customers.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 40, color: '#666' }}>
            <p>No customers found.</p>
            {search || statusFilter !== 'All' ? (
              <button className="btn-secondary btn-sm" style={{ marginTop: 12 }} onClick={() => { setSearch(''); setStatusFilter('All'); }}>
                Clear Filters
              </button>
            ) : (
              <Link href="/customers/add">
                <button className="btn-primary btn-sm" style={{ marginTop: 12 }}>Add First Customer</button>
              </Link>
            )}
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Customer Name</th>
                  <th>Email Address</th>
                  <th>Phone</th>
                  <th>Company</th>
                  <th>Status</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {customers.map((c) => (
                  <tr key={c._id}>
                    <td style={{ fontWeight: 600 }}>{c.name}</td>
                    <td>{c.email}</td>
                    <td>{c.phone}</td>
                    <td>{c.company || '—'}</td>
                    <td>{statusBadge(c.status)}</td>
                    <td>{new Date(c.createdAt).toLocaleDateString()}</td>
                    <td>
                      <div className="action-btns">
                        <button
                          className="btn-secondary btn-sm"
                          onClick={() => router.push(`/customers/edit/${c._id}`)}
                        >
                          ✏️ Edit
                        </button>
                        <button
                          className="btn-danger btn-sm"
                          onClick={() => setDeleteId(c._id)}
                        >
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="pagination">
            <button className="page-btn" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>‹</button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button key={p} className={`page-btn ${page === p ? 'active' : ''}`} onClick={() => setPage(p)}>{p}</button>
            ))}
            <button className="page-btn" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}>›</button>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteId && (
        <div className="modal-overlay" onClick={() => setDeleteId(null)}>
          <div className="modal" style={{ maxWidth: 400 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Confirm Delete</h3>
              <button className="modal-close" onClick={() => setDeleteId(null)}>✕</button>
            </div>
            <p style={{ color: '#666', marginBottom: 24 }}>
              Are you sure you want to delete this customer? This action cannot be undone.
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button className="btn-secondary" onClick={() => setDeleteId(null)}>Cancel</button>
              <button className="btn-danger" onClick={handleDelete}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}

export default withAuth(Customers);
