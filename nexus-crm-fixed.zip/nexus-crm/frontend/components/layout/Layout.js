import { useRouter } from 'next/router';
import Link from 'next/link';
import { useAuth } from '../../context/AuthContext';
import Chatbot from '../ui/Chatbot';

const navItems = [
  { label: 'Dashboard', icon: '📊', href: '/dashboard' },
  { label: 'Customers', icon: '👥', href: '/customers' },
  { label: 'Invoices', icon: '🧾', href: '/invoices' },
  { label: 'Settings', icon: '⚙️', href: '/settings' },
];

export default function Layout({ children }) {
  const router = useRouter();
  const { user, logout } = useAuth();

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="sidebar-logo">
          <h2>Nexus CRM</h2>
          <span>Enterprise Edition</span>
        </div>

        <nav className="sidebar-nav">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <div className={`nav-item ${router.pathname.startsWith(item.href) ? 'active' : ''}`}>
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </div>
            </Link>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontWeight: 600 }}>{user?.name}</div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>{user?.role}</div>
          </div>
          <button
            onClick={logout}
            style={{ background: 'rgba(255,255,255,0.15)', color: 'white', width: '100%', marginTop: 4 }}
          >
            Logout
          </button>
        </div>
      </aside>

      <main className="main-content">
        {children}
      </main>

      <Chatbot />
    </div>
  );
}
